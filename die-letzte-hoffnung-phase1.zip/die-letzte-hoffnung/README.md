# Die letzte Hoffnung – Phase 1
Starten: Ordner über einen lokalen Webserver öffnen (z. B. `python3 -m http.server 8000`, dann http://localhost:8000).
Three.js wird von cdn.jsdelivr.net geladen (kostenlos, Version 0.160.0 fest eingestellt).

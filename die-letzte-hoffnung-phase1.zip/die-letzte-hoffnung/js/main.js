import * as THREE from 'three';
import { buildWorld, heightAt } from './world.js';
import { Player } from './player.js';
import { input, initInput, readMove } from './input.js';

const SAVE_KEY = 'dlh_save_v1';
const errBox = document.getElementById('err');
addEventListener('error', e => { errBox.textContent = 'Fehler: ' + e.message; });

async function start() {
  const cfg = await (await fetch('data/config.json')).json();
  const canvas = document.getElementById('game');
  initInput(canvas, cfg.camera);
  const low = input.touch;                                   // iPad/Handy: Schatten aus, Pixeldichte begrenzt

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: !low, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, low ? 1.5 : 2));
  renderer.shadowMap.enabled = !low;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xa9c8dc);
  scene.fog = new THREE.Fog(0xa9c8dc, 70, 260);
  const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 400);

  scene.add(new THREE.HemisphereLight(0xdceeff, 0x4b5a3a, 0.85));
  const sun = new THREE.DirectionalLight(0xfff0d0, 1.5);
  sun.position.set(60, 90, 40);
  if (!low) { sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048); Object.assign(sun.shadow.camera, { left: -40, right: 40, top: 40, bottom: -40, near: 1, far: 220 }); }
  scene.add(sun, sun.target);

  const world = buildWorld(scene, cfg, low);
  const player = new Player(scene, cfg, world, low);

  try {                                                      // Spielstand laden
    const s = JSON.parse(localStorage.getItem(SAVE_KEY));
    if (s) { player.pos.set(s.x, s.y, s.z); input.yaw = s.yaw; }
  } catch {}
  const save = () => { try { localStorage.setItem(SAVE_KEY, JSON.stringify({ x: player.pos.x, y: player.pos.y, z: player.pos.z, yaw: input.yaw })); } catch {} };
  setInterval(save, 5000); addEventListener('pagehide', save);

  const resize = () => { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); };
  addEventListener('resize', resize); resize();

  let dist = cfg.camera.dist; const camPos = new THREE.Vector3(), target = new THREE.Vector3();
  const posEl = document.getElementById('pos'), fpsEl = document.getElementById('fps');
  let last = performance.now(), frames = 0, acc = 0;

  renderer.setAnimationLoop(now => {
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    player.update(dt, readMove(), input.yaw, input);

    dist = Math.max(cfg.camera.min, Math.min(cfg.camera.max, dist + input.zoom)); input.zoom = 0;
    const cp = Math.cos(input.pitch), sp = Math.sin(input.pitch);
    target.set(player.pos.x, player.pos.y + 1.6, player.pos.z);
    const want = new THREE.Vector3(target.x + Math.sin(input.yaw) * cp * dist, target.y + sp * dist, target.z + Math.cos(input.yaw) * cp * dist);
    want.y = Math.max(want.y, heightAt(want.x, want.z) + 0.8);   // Kamera nicht unter den Boden
    camPos.lerp(want, Math.min(1, dt * 12));
    camera.position.copy(camPos); camera.lookAt(target);

    sun.position.set(player.pos.x + 60, 90, player.pos.z + 40); sun.target.position.copy(player.pos);
    renderer.render(scene, camera);

    acc += dt; frames++;
    if (acc > 0.5) { fpsEl.textContent = Math.round(frames / acc) + ' FPS'; posEl.textContent = `X ${player.pos.x.toFixed(0)}  Z ${player.pos.z.toFixed(0)}`; acc = frames = 0; }
  });
}

document.getElementById('go').addEventListener('click', () => {
  document.getElementById('start').style.display = 'none';
  start().catch(e => { errBox.textContent = 'Start fehlgeschlagen: ' + e.message; });
});

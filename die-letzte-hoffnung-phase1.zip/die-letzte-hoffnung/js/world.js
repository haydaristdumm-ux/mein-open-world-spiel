import * as THREE from 'three';

export function heightAt(x, z) {
  const d = Math.hypot(x, z);
  let h = Math.sin(x * 0.021) * 4 + Math.cos(z * 0.026) * 4 + Math.sin((x + z) * 0.05) * 1.6 + Math.sin(x * 0.11) * Math.cos(z * 0.09) * 0.6;
  const ring = Math.min(1, Math.max(0, (d - 110) / 90));
  h += ring * ring * 55 + Math.sin(x * 0.07 + z * 0.05) * ring * 9;
  const flat = Math.min(1, Math.max(0, 1 - (d - 12) / 28));
  return h * (1 - flat * flat * (3 - 2 * flat));
}

function rng(seed) { return () => (seed = (seed * 16807) % 2147483647) / 2147483647; }

export function buildWorld(scene, cfg, lowPower) {
  const W = cfg.world, colliders = [], rand = rng(42);

  // Gelände
  const geo = new THREE.PlaneGeometry(W.size, W.size, W.segments, W.segments);
  geo.rotateX(-Math.PI / 2);
  const p = geo.attributes.position, col = new Float32Array(p.count * 3), c = new THREE.Color();
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), z = p.getZ(i), h = heightAt(x, z);
    p.setY(i, h);
    const slope = Math.abs(heightAt(x + 1.5, z) - h) + Math.abs(heightAt(x, z + 1.5) - h);
    if (h < W.waterLevel + 0.8) c.set(0xc9b983);
    else if (h > 38) c.set(0xf2f4f6);
    else if (slope > 2.1 || h > 24) c.set(0x7d7a74);
    else c.setHSL(0.27 + rand() * 0.03, 0.42, 0.34 + rand() * 0.06);
    col.set([c.r, c.g, c.b], i * 3);
  }
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  geo.computeVertexNormals();
  const terrain = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true }));
  terrain.receiveShadow = !lowPower;
  scene.add(terrain);

  const water = new THREE.Mesh(new THREE.PlaneGeometry(W.size, W.size),
    new THREE.MeshLambertMaterial({ color: 0x2f6f8f, transparent: true, opacity: 0.75 }));
  water.rotation.x = -Math.PI / 2; water.position.y = W.waterLevel;
  scene.add(water);

  // Bäume (instanziert = schnell)
  const trunk = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.22, 0.32, 2.2, 6), new THREE.MeshLambertMaterial({ color: 0x5a3b22 }), W.treeCount);
  const crown = new THREE.InstancedMesh(new THREE.ConeGeometry(1.6, 4.2, 7), new THREE.MeshLambertMaterial({ color: 0x2c5a2a }), W.treeCount);
  const m = new THREE.Matrix4(); let n = 0;
  for (let t = 0; t < W.treeCount * 4 && n < W.treeCount; t++) {
    const x = (rand() - 0.5) * W.size * 0.8, z = (rand() - 0.5) * W.size * 0.8, h = heightAt(x, z);
    if (Math.hypot(x, z) < 22 || h < W.waterLevel + 1 || h > 20) continue;
    const s = 0.8 + rand() * 0.8;
    m.makeScale(s, s, s).setPosition(x, h + 1.1 * s, z); trunk.setMatrixAt(n, m);
    m.makeScale(s, s, s).setPosition(x, h + 4 * s, z); crown.setMatrixAt(n, m);
    colliders.push({ x, z, r: 0.6 * s }); n++;
  }
  trunk.count = crown.count = n;
  trunk.castShadow = crown.castShadow = !lowPower;
  scene.add(trunk, crown);

  // Felsen
  const rocks = new THREE.InstancedMesh(new THREE.DodecahedronGeometry(1, 0), new THREE.MeshLambertMaterial({ color: 0x777777 }), W.rockCount);
  for (let i = 0; i < W.rockCount; i++) {
    const x = (rand() - 0.5) * W.size * 0.8, z = (rand() - 0.5) * W.size * 0.8, s = 0.7 + rand() * 1.8;
    m.makeScale(s, s * 0.7, s).setPosition(x, heightAt(x, z) + 0.2, z); rocks.setMatrixAt(i, m);
    colliders.push({ x, z, r: s * 0.9 });
  }
  scene.add(rocks);

  // Dorf Eichenfels (Häuser mit Dach)
  const wall = new THREE.MeshLambertMaterial({ color: 0xcdb48a }), roof = new THREE.MeshLambertMaterial({ color: 0x8a3b2a });
  [[-12, -10], [-4, -14], [6, -13], [14, -8], [-14, 2], [15, 4]].forEach(([x, z], i) => {
    const g = new THREE.Group(), h = heightAt(x, z);
    const b = new THREE.Mesh(new THREE.BoxGeometry(5, 3, 4), wall); b.position.y = 1.5;
    const r = new THREE.Mesh(new THREE.ConeGeometry(4.2, 2.2, 4), roof); r.position.y = 4.1; r.rotation.y = Math.PI / 4;
    b.castShadow = r.castShadow = !lowPower;
    g.add(b, r); g.position.set(x, h, z); g.rotation.y = i * 0.7; scene.add(g);
    colliders.push({ x, z, r: 3.4 });
  });

  return { colliders };
}

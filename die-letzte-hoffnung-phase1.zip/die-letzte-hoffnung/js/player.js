import * as THREE from 'three';
import { heightAt } from './world.js';

const mat = c => new THREE.MeshLambertMaterial({ color: c });

export class Player {
  constructor(scene, cfg, world, lowPower) {
    this.cfg = cfg; this.colliders = world.colliders;
    this.pos = new THREE.Vector3(0, 0, 6); this.vel = new THREE.Vector3();
    this.heading = Math.PI; this.onGround = true; this.dodgeT = 0; this.attackT = 0; this.phase = 0;

    const g = this.model = new THREE.Group();
    const part = (geo, color, x, y, z) => { const m = new THREE.Mesh(geo, mat(color)); m.position.set(x, y, z); m.castShadow = !lowPower; return m; };
    this.body = new THREE.Group(); g.add(this.body);
    this.body.add(part(new THREE.BoxGeometry(0.7, 0.85, 0.4), 0x2d4f8a, 0, 1.25, 0));          // Tunika
    this.body.add(part(new THREE.BoxGeometry(0.72, 0.18, 0.42), 0x5a3b22, 0, 0.85, 0));        // Gürtel
    this.body.add(part(new THREE.SphereGeometry(0.28, 12, 10), 0xe2b48c, 0, 1.92, 0));         // Kopf
    this.body.add(part(new THREE.SphereGeometry(0.3, 12, 8, 0, 6.3, 0, 1.3), 0x5b3a1e, 0, 1.97, -0.02)); // Haare
    this.legL = new THREE.Group(); this.legR = new THREE.Group();
    this.legL.position.set(-0.17, 0.85, 0); this.legR.position.set(0.17, 0.85, 0);
    this.legL.add(part(new THREE.BoxGeometry(0.25, 0.85, 0.3), 0x3a3a3a, 0, -0.42, 0));
    this.legR.add(part(new THREE.BoxGeometry(0.25, 0.85, 0.3), 0x3a3a3a, 0, -0.42, 0));
    this.armL = new THREE.Group(); this.armR = new THREE.Group();
    this.armL.position.set(-0.47, 1.62, 0); this.armR.position.set(0.47, 1.62, 0);
    this.armL.add(part(new THREE.BoxGeometry(0.2, 0.7, 0.24), 0x2d4f8a, 0, -0.32, 0));
    this.armR.add(part(new THREE.BoxGeometry(0.2, 0.7, 0.24), 0x2d4f8a, 0, -0.32, 0));
    const sword = new THREE.Group();
    sword.add(part(new THREE.BoxGeometry(0.07, 0.95, 0.03), 0xc9d2dc, 0, -1.05, 0.0));
    sword.add(part(new THREE.BoxGeometry(0.28, 0.06, 0.06), 0xb08a3a, 0, -0.58, 0));
    sword.rotation.x = -Math.PI / 2; sword.position.set(0, -0.62, 0.25);
    this.armR.add(sword);
    this.body.add(this.legL, this.legR, this.armL, this.armR);
    scene.add(g);
  }

  update(dt, mv, camYaw, input) {
    const c = this.cfg.player, v = this.vel;
    const fx = -Math.sin(camYaw), fz = -Math.cos(camYaw), rx = Math.cos(camYaw), rz = -Math.sin(camYaw);
    let wx = fx * mv.y + rx * mv.x, wz = fz * mv.y + rz * mv.x;
    const mag = Math.hypot(wx, wz);

    if (input.dodge && this.dodgeT <= 0 && this.onGround) {
      this.dodgeT = c.dodgeTime;
      if (mag > 0.1) this.heading = Math.atan2(wx, wz);
    }
    input.dodge = false;
    if (input.attack && this.attackT <= 0 && this.dodgeT <= 0) this.attackT = 0.45;
    input.attack = false;

    const water = this.pos.y < this.cfg.world.waterLevel;
    let speed = (mv.sprint ? c.sprint : c.walk) * (water ? 0.55 : 1) * (this.attackT > 0 ? 0.5 : 1);
    let tx = wx * speed, tz = wz * speed;
    if (this.dodgeT > 0) { this.dodgeT -= dt; tx = Math.sin(this.heading) * c.dodgeSpeed; tz = Math.cos(this.heading) * c.dodgeSpeed; }
    else if (mag > 0.1) {
      let d = Math.atan2(wx, wz) - this.heading; d = Math.atan2(Math.sin(d), Math.cos(d));
      this.heading += d * Math.min(1, dt * 12);
    }
    const k = this.onGround ? 14 : 4;
    v.x += (tx - v.x) * Math.min(1, dt * k); v.z += (tz - v.z) * Math.min(1, dt * k);

    if (input.jump && this.onGround && this.dodgeT <= 0) { v.y = c.jump; this.onGround = false; }
    input.jump = false;
    v.y -= c.gravity * dt;
    this.pos.addScaledVector(v, dt);

    for (const o of this.colliders) {           // Kollision mit Bäumen, Felsen, Häusern
      const dx = this.pos.x - o.x, dz = this.pos.z - o.z, min = o.r + c.radius;
      if (Math.abs(dx) > min || Math.abs(dz) > min) continue;
      const d = Math.hypot(dx, dz);
      if (d < min && d > 0.0001) { this.pos.x = o.x + dx / d * min; this.pos.z = o.z + dz / d * min; }
    }
    const lim = this.cfg.world.size / 2 - 3;
    this.pos.x = Math.max(-lim, Math.min(lim, this.pos.x)); this.pos.z = Math.max(-lim, Math.min(lim, this.pos.z));

    const gy = heightAt(this.pos.x, this.pos.z);
    if (this.pos.y <= gy) { this.pos.y = gy; v.y = 0; this.onGround = true; } else if (this.pos.y > gy + 0.15) this.onGround = false;

    this.animate(dt, Math.hypot(v.x, v.z));
  }

  animate(dt, sp) {
    this.phase += dt * (3 + sp * 1.4);
    const sw = this.onGround ? Math.min(1, sp / 6) * 0.9 : 0.3, s = Math.sin(this.phase);
    this.legL.rotation.x = s * sw; this.legR.rotation.x = -s * sw;
    this.armL.rotation.x = -s * sw * 0.8;
    if (this.attackT > 0) { this.attackT -= dt; const t = 1 - this.attackT / 0.45; this.armR.rotation.x = -Math.PI * 0.9 + Math.sin(t * Math.PI) * 2.2; }
    else this.armR.rotation.x = s * sw * 0.8 - 0.2;
    this.body.rotation.x = this.dodgeT > 0 ? (1 - this.dodgeT / this.cfg.player.dodgeTime) * Math.PI * 2 : 0;
    this.body.position.y = this.dodgeT > 0 ? 0.7 : 0;
    this.model.position.copy(this.pos); this.model.rotation.y = this.heading;
  }
}

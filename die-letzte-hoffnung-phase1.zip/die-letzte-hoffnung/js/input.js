export const input = {
  move: { x: 0, y: 0 }, sprint: false, keys: {}, touch: false,
  yaw: 0, pitch: 0.35, zoom: 0, jump: false, dodge: false, attack: false,
};

export function initInput(canvas, cam) {
  input.touch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
  document.body.classList.toggle('touch', input.touch);

  addEventListener('keydown', e => {
    input.keys[e.code] = true;
    if (e.code === 'Space') input.jump = true;
    if (e.code === 'KeyC' || e.code === 'ControlLeft') input.dodge = true;
    if (['Space', 'ArrowUp', 'ArrowDown'].includes(e.code)) e.preventDefault();
  });
  addEventListener('keyup', e => { input.keys[e.code] = false; });

  const look = (dx, dy) => {
    input.yaw -= dx * cam.sensitivity;
    input.pitch = Math.max(-0.2, Math.min(1.2, input.pitch + dy * cam.sensitivity));
  };
  canvas.addEventListener('click', e => { if (e.pointerType === 'mouse' && !document.pointerLockElement) canvas.requestPointerLock?.(); });
  addEventListener('mousedown', e => { if (e.button === 0 && document.pointerLockElement) input.attack = true; });
  addEventListener('mousemove', e => { if (document.pointerLockElement) look(e.movementX, e.movementY); });
  addEventListener('wheel', e => { input.zoom += Math.sign(e.deltaY) * 0.8; }, { passive: true });

  // Touch: Kamera ziehen (rechte Bildschirmseite) und Pinch-Zoom
  const pts = new Map();
  canvas.addEventListener('pointerdown', e => { if (e.pointerType !== 'mouse') pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); });
  canvas.addEventListener('pointermove', e => {
    const p = pts.get(e.pointerId); if (!p) return;
    if (pts.size === 2) {
      const [a, b] = [...pts.values()], before = Math.hypot(a.x - b.x, a.y - b.y);
      p.x = e.clientX; p.y = e.clientY;
      input.zoom -= (Math.hypot(a.x - b.x, a.y - b.y) - before) * 0.03;
    } else { look(e.clientX - p.x, e.clientY - p.y); p.x = e.clientX; p.y = e.clientY; }
  });
  ['pointerup', 'pointercancel'].forEach(t => canvas.addEventListener(t, e => pts.delete(e.pointerId)));

  // Joystick
  const stick = document.getElementById('stick'), knob = document.getElementById('knob');
  let sid = null; const R = 50;
  const setStick = e => {
    const r = stick.getBoundingClientRect(), dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    const d = Math.min(R, Math.hypot(dx, dy)), a = Math.atan2(dy, dx);
    const sx = Math.cos(a) * d, sy = Math.sin(a) * d;
    knob.style.transform = `translate(${sx}px,${sy}px)`;
    input.move.x = sx / R; input.move.y = -sy / R; input.sprint = d > R * 0.9;
  };
  stick.addEventListener('pointerdown', e => { sid = e.pointerId; stick.setPointerCapture(sid); setStick(e); });
  stick.addEventListener('pointermove', e => { if (e.pointerId === sid) setStick(e); });
  const endStick = e => { if (e.pointerId !== sid) return; sid = null; knob.style.transform = ''; input.move.x = input.move.y = 0; input.sprint = false; };
  stick.addEventListener('pointerup', endStick); stick.addEventListener('pointercancel', endStick);

  document.querySelectorAll('#touch button').forEach(b =>
    b.addEventListener('pointerdown', e => { e.preventDefault(); input[b.dataset.act] = true; }));
}

export function readMove() {
  const k = input.keys;
  let x = input.move.x + ((k.KeyD || k.ArrowRight) ? 1 : 0) - ((k.KeyA || k.ArrowLeft) ? 1 : 0);
  let y = input.move.y + ((k.KeyW || k.ArrowUp) ? 1 : 0) - ((k.KeyS || k.ArrowDown) ? 1 : 0);
  const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
  return { x, y, sprint: input.sprint || !!(k.ShiftLeft || k.ShiftRight) };
}
